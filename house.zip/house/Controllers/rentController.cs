﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using house.Models;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace house.Controllers
{
    public class rentController : ApiController
    {
        public String errorMsg = "";
        public HttpResponseMessage Get ()
        {
            DataTable table = new DataTable ();
            string query = @"Select ID,name,image_url,email,phone,address,review from 
                           dbo.Rent";
            String connectionString = "Data Source=.;Initial Catalog=rent;Integrated Security=True";

            using (var con = new SqlConnection(connectionString) )
             using (var cmd = new SqlCommand (query, con))
            using (var da =new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse (HttpStatusCode.OK, table);
        }
        public string Post(rent add)
        {
            try
            {
                DataTable table = new DataTable();
                string query = @"
                              insert into dbo.Rent
                              (name,
                              image_url,
                              email,
                              phone, 
                              address, 
                              review)
                              values 
                              ('" + add.name + @"','" + add.image_url + @"'
                              ,'" + add.email + @"'
                              ,'" + add.phone + @"'
                              ,'" + add.address + @"'
                              ,'" + add.review + @"'
                               )
                              ";

                String connectionString = "Data Source=.;Initial Catalog=rent;Integrated Security=True";


                using (var con = new SqlConnection(connectionString)) 
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfully";
            }
            catch (Exception ex) 
            {
                errorMsg = ex.Message;
                return errorMsg;
            }
        }


    }
}
